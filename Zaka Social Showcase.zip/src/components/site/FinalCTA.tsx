import { Reveal } from "./Reveal";

export function FinalCTA() {
  return (
    <section className="relative overflow-hidden bg-ink py-32 text-ink-foreground md:py-44">
      <div
        className="pointer-events-none absolute -right-32 top-1/2 h-[36rem] w-[36rem] -translate-y-1/2 rounded-full bg-primary/20 blur-[120px]"
        style={{ animation: "float-slow 9s ease-in-out infinite" }}
      />
      <div className="relative mx-auto max-w-4xl px-6 text-center lg:px-10">
        <Reveal>
          <h2 className="font-display text-[clamp(2.4rem,6vw,4.8rem)] font-medium leading-[1] tracking-[-0.02em] text-balance">
            Ready to build a brand people{" "}
            <span className="italic text-primary">remember?</span>
          </h2>
        </Reveal>
        <Reveal delay={120}>
          <p className="mx-auto mt-8 max-w-2xl text-base leading-relaxed text-ink-foreground/65 md:text-lg">
            Whether you're launching, growing, or repositioning your business,
            we'll help create a content and marketing strategy that supports
            where you're headed next.
          </p>
        </Reveal>
        <Reveal delay={220}>
          <a
            href="#contact"
            className="mt-11 inline-flex items-center justify-center rounded-full bg-primary px-10 py-4 text-sm font-semibold text-primary-foreground transition-all duration-300 hover:scale-[1.03] hover:shadow-2xl hover:shadow-primary/25"
          >
            Get Started
          </a>
        </Reveal>
      </div>
    </section>
  );
}
