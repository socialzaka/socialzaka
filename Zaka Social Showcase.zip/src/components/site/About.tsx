import { Reveal } from "./Reveal";
import aboutImg from "@/assets/about-tailored.png.asset.json";

const stats = [
  { value: "Strategy", label: "Built before content" },
  { value: "Clarity", label: "Messaging that lands" },
  { value: "Growth", label: "Outcomes, not vanity" },
];

export function About() {
  return (
    <section id="about" className="bg-background py-28 md:py-40">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="grid items-center gap-14 lg:grid-cols-2 lg:gap-20">
          <Reveal className="order-2 lg:order-1">
            <div className="flex items-center gap-3 text-muted-foreground">
              <span className="h-px w-10 bg-primary" />
              <span className="eyebrow text-primary">About</span>
            </div>
            <h2 className="mt-6 font-display text-[clamp(2rem,4.5vw,3.4rem)] font-medium leading-[1.02] tracking-[-0.02em] text-balance">
              Strategy first. <span className="italic text-primary">Content second.</span>
            </h2>
            <div className="mt-8 space-y-6 text-base leading-relaxed text-muted-foreground md:text-lg">
              <p>
                At Zaka Social, we believe great marketing starts long before a
                post goes live. We help businesses clarify their message,
                understand their audience, and create content that supports real
                business goals.
              </p>
              <p>
                From content planning and copywriting to social media strategy and
                brand positioning, every recommendation is built around helping
                your business grow in a way that feels intentional, sustainable,
                and aligned with your brand.
              </p>
            </div>

            <div className="mt-12 grid grid-cols-3 gap-4 border-t border-border pt-8">
              {stats.map((s) => (
                <div key={s.value}>
                  <div className="font-display text-xl font-semibold text-foreground md:text-2xl">
                    {s.value}
                  </div>
                  <div className="mt-1 text-xs leading-snug text-muted-foreground">
                    {s.label}
                  </div>
                </div>
              ))}
            </div>
          </Reveal>

          <Reveal className="order-1 lg:order-2" delay={120}>
            <div className="relative">
              <div className="overflow-hidden rounded-[2rem]">
                <img
                  src={aboutImg.url}
                  alt="Editorial still life representing the Zaka Social brand aesthetic"
                  loading="lazy"
                  width={1024}
                  height={1024}
                  className="aspect-[4/5] w-full object-cover transition-transform duration-700 hover:scale-105"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 hidden rounded-2xl bg-ink px-7 py-6 text-ink-foreground shadow-2xl sm:block">
                <div className="font-display text-3xl font-semibold text-primary">100%</div>
                <div className="mt-1 max-w-[10rem] text-xs leading-snug text-ink-foreground/70">
                  Tailored to your brand, never templated
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
