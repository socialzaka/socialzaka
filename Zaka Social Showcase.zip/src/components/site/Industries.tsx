import { Reveal } from "./Reveal";

const industries = [
  "Real Estate",
  "Hospitality",
  "Restaurants",
  "Wellness",
  "Beauty & Cosmetics",
  "Healthcare",
  "Local Businesses",
  "Personal Brands",
];

export function Industries() {
  return (
    <section className="bg-ink py-28 text-ink-foreground md:py-40">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <Reveal className="max-w-2xl">
          <div className="flex items-center gap-3 text-ink-foreground/50">
            <span className="h-px w-10 bg-primary" />
            <span className="eyebrow text-primary">Industries</span>
          </div>
          <h2 className="mt-6 font-display text-[clamp(2rem,4.5vw,3.4rem)] font-medium leading-[1.02] tracking-[-0.02em]">
            Industries we <span className="italic text-primary">love</span> working with.
          </h2>
        </Reveal>

        <div className="mt-16 grid gap-px overflow-hidden rounded-3xl border border-ink-foreground/10 bg-ink-foreground/10 sm:grid-cols-2 lg:grid-cols-4">
          {industries.map((name, i) => (
            <Reveal
              key={name}
              delay={(i % 4) * 70}
              className="group flex min-h-[9rem] flex-col justify-between bg-ink p-7 transition-colors duration-500 hover:bg-primary"
            >
              <span className="font-display text-sm text-ink-foreground/40 transition-colors group-hover:text-primary-foreground/70">
                0{i + 1}
              </span>
              <h3 className="font-display text-xl font-medium leading-tight tracking-tight transition-colors group-hover:text-primary-foreground">
                {name}
              </h3>
            </Reveal>
          ))}
        </div>

        <Reveal>
          <p className="mt-12 max-w-2xl text-base leading-relaxed text-ink-foreground/60">
            While these are some of our most common industries, we enjoy
            partnering with ambitious businesses across all sectors.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
