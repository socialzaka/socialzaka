import heroImg from "@/assets/hero.jpg";

export function Hero() {
  return (
    <section id="home" className="relative overflow-hidden bg-ink text-ink-foreground">
      {/* Ambient image */}
      <div className="pointer-events-none absolute inset-0">
        <img
          src={heroImg}
          alt=""
          width={1080}
          height={1920}
          className="absolute right-0 top-0 h-full w-full object-cover opacity-50 md:w-3/5 md:opacity-70"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/85 to-ink/30" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-transparent" />
      </div>

      <div className="relative mx-auto flex min-h-screen max-w-7xl flex-col justify-center px-6 pb-20 pt-32 lg:px-10">
        <div
          className="reveal is-visible flex items-center gap-3 text-ink-foreground/60"
          style={{ animation: "none" }}
        >
          <span className="h-px w-10 bg-primary" />
          <span className="eyebrow text-primary">Zaka Social</span>
        </div>

        <h1 className="mt-7 max-w-4xl font-display text-[clamp(2.6rem,7vw,5.6rem)] font-medium leading-[0.98] tracking-[-0.02em] text-balance">
          Your brand deserves more than{" "}
          <span className="italic text-primary">just posts.</span>
        </h1>

        <p className="mt-8 max-w-xl text-lg leading-relaxed text-ink-foreground/70 md:text-xl">
          We create content, messaging, and social media strategies that help
          businesses stand out, stay relevant, and grow with intention.
        </p>

        <p className="mt-6 max-w-2xl text-sm leading-relaxed text-ink-foreground/50 md:text-base">
          Every successful brand tells a clear story. Through strategic content,
          thoughtful messaging, and audience-focused marketing, we help businesses
          build visibility, trust, and momentum online.
        </p>

        <div className="mt-11 flex flex-col gap-4 sm:flex-row">
          <a
            href="#contact"
            className="inline-flex items-center justify-center rounded-full bg-primary px-8 py-4 text-sm font-semibold text-primary-foreground transition-all duration-300 hover:scale-[1.03] hover:shadow-2xl hover:shadow-primary/20"
          >
            Get Started
          </a>
          <a
            href="#services"
            className="inline-flex items-center justify-center rounded-full border border-ink-foreground/25 px-8 py-4 text-sm font-semibold text-ink-foreground transition-all duration-300 hover:border-ink-foreground/60 hover:bg-ink-foreground/5"
          >
            View Services
          </a>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-ink-foreground/40 lg:flex">
        <span className="eyebrow text-[0.6rem]">Scroll</span>
        <span className="h-10 w-px animate-pulse bg-ink-foreground/30" />
      </div>
    </section>
  );
}
