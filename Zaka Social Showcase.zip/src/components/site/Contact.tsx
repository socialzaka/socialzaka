import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { z } from "zod";
import { Reveal } from "./Reveal";

const contactSchema = z.object({
  name: z.string().trim().min(1, "Please add your name.").max(100),
  email: z.string().trim().email("Please add a valid email.").max(255),
  business: z.string().trim().max(120).optional(),
  message: z.string().trim().min(1, "Please add a message.").max(1500),
});

export function Contact() {
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSubmitting(true);

    const form = e.currentTarget;
    const formData = new FormData(form);

    const result = contactSchema.safeParse({
      name: formData.get("name"),
      email: formData.get("email"),
      business: formData.get("business"),
      message: formData.get("message"),
    });

    if (!result.success) {
      setSubmitting(false);
      toast.error("Please check the contact form.", {
        description: result.error.errors[0]?.message ?? "Some details need attention.",
      });
      return;
    }

    formData.set("name", result.data.name);
    formData.set("email", result.data.email);
    formData.set("business", result.data.business ?? "");
    formData.set("message", result.data.message);
    formData.set("_subject", "New message from Zaka Social website");
    formData.set("_template", "table");
    formData.set("_captcha", "false");

    try {
      const response = await fetch("https://formsubmit.co/ajax/socialzaka@gmail.com", {
        method: "POST",
        headers: { Accept: "application/json" },
        body: formData,
      });

      if (!response.ok) throw new Error("Message could not be sent.");

      form.reset();
      toast.success("Thanks — we'll be in touch shortly.", {
        description: "Your message has been sent to socialzaka@gmail.com.",
      });
    } catch {
      toast.error("Your message could not be sent.", {
        description: "Please try again in a moment.",
      });
    } finally {
      setSubmitting(false);
    }
  }

  const fieldClass =
    "w-full border-b border-border bg-transparent py-3 text-base text-foreground placeholder:text-muted-foreground/60 transition-colors focus:border-primary focus:outline-none";

  return (
    <section id="contact" className="bg-background py-28 md:py-40">
      <div className="mx-auto max-w-6xl px-6 lg:px-10">
        <div className="grid gap-14 lg:grid-cols-2 lg:gap-24">
          <Reveal>
            <div className="flex items-center gap-3 text-muted-foreground">
              <span className="h-px w-10 bg-primary" />
              <span className="eyebrow text-primary">Contact</span>
            </div>
            <h2 className="mt-6 font-display text-[clamp(2rem,4.5vw,3.4rem)] font-medium leading-[1.02] tracking-[-0.02em] text-balance">
              Let's start the <span className="italic text-primary">conversation.</span>
            </h2>
            <p className="mt-7 max-w-md text-base leading-relaxed text-muted-foreground">
              Tell us a little about your business and what you're hoping to
              achieve. We'll get back to you with thoughtful next steps.
            </p>
            <div className="mt-10 space-y-1">
              <div className="eyebrow text-muted-foreground">Email</div>
              <a
                href="mailto:socialzaka@gmail.com"
                className="font-display text-xl text-foreground transition-colors hover:text-primary"
              >
                socialzaka@gmail.com
              </a>
            </div>
          </Reveal>

          <Reveal delay={120}>
            <form onSubmit={handleSubmit} className="space-y-7">
              <div className="grid gap-7 sm:grid-cols-2">
                <input required name="name" placeholder="Name" className={fieldClass} />
                <input
                  required
                  type="email"
                  name="email"
                  placeholder="Email"
                  className={fieldClass}
                />
              </div>
              <input
                name="business"
                placeholder="Business Name"
                className={fieldClass}
              />
              <textarea
                required
                name="message"
                placeholder="Message"
                rows={4}
                className={`${fieldClass} resize-none`}
              />
              <button
                type="submit"
                disabled={submitting}
                className="inline-flex items-center justify-center rounded-full bg-foreground px-9 py-4 text-sm font-semibold text-background transition-all duration-300 hover:bg-primary hover:text-primary-foreground disabled:opacity-60"
              >
                {submitting ? "Sending…" : "Let's Talk"}
              </button>
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
