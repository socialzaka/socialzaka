import { Reveal } from "./Reveal";
import {
  Compass,
  CalendarRange,
  PenLine,
  Lightbulb,
  Globe,
  LineChart,
} from "lucide-react";

const services = [
  {
    icon: Compass,
    title: "Social Media Strategy",
    desc: "Build a clear roadmap for content, audience growth, and brand positioning.",
  },
  {
    icon: CalendarRange,
    title: "Content Planning",
    desc: "Monthly content systems designed to keep your brand consistent and visible.",
  },
  {
    icon: PenLine,
    title: "Copywriting",
    desc: "Captions, messaging, and website copy that communicate value and encourage action.",
  },
  {
    icon: Lightbulb,
    title: "Content Direction",
    desc: "Creative concepts and content ideas designed to connect with the right audience.",
  },
  {
    icon: Globe,
    title: "Website Creation",
    desc: "Beautiful, conversion-focused websites that capture your brand's essence and turn visitors into loyal clients.",
  },
  {
    icon: LineChart,
    title: "Content Audits",
    desc: "Identify opportunities to improve engagement, visibility, and overall performance.",
  },
];

export function Services() {
  return (
    <section id="services" className="bg-cream py-28 md:py-40">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <Reveal className="max-w-2xl">
          <div className="flex items-center gap-3 text-muted-foreground">
            <span className="h-px w-10 bg-primary" />
            <span className="eyebrow text-primary">Services</span>
          </div>
          <h2 className="mt-6 font-display text-[clamp(2rem,4.5vw,3.4rem)] font-medium leading-[1.02] tracking-[-0.02em] text-balance">
            Everything your brand needs to be{" "}
            <span className="italic text-primary">impossible to ignore.</span>
          </h2>
        </Reveal>

        <div className="mt-16 grid gap-px overflow-hidden rounded-3xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s, i) => (
            <Reveal
              key={s.title}
              delay={(i % 3) * 90}
              className="group relative bg-card p-9 transition-colors duration-500 hover:bg-ink"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-full border border-border text-primary transition-colors duration-500 group-hover:border-primary/40 group-hover:bg-primary/10">
                <s.icon className="h-5 w-5" strokeWidth={1.6} />
              </div>
              <h3 className="mt-7 font-display text-xl font-semibold tracking-tight transition-colors duration-500 group-hover:text-ink-foreground">
                {s.title}
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground transition-colors duration-500 group-hover:text-ink-foreground/70">
                {s.desc}
              </p>
              <span className="mt-8 inline-block font-display text-sm text-border transition-colors duration-500 group-hover:text-primary">
                0{i + 1}
              </span>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
