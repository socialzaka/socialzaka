import { Instagram, Mail } from "lucide-react";

const socials = [
  { icon: Instagram, label: "Instagram", href: "https://www.instagram.com/zakasocial/" },
  { icon: Mail, label: "Email", href: "mailto:socialzaka@gmail.com" },
];

export function Footer() {
  return (
    <footer className="bg-ink text-ink-foreground">
      <div className="mx-auto max-w-7xl px-6 py-16 lg:px-10">
        <div className="flex flex-col items-start justify-between gap-10 border-b border-ink-foreground/10 pb-12 md:flex-row md:items-center">
          <div>
            <div className="font-display text-3xl font-medium">
              Zaka <span className="italic text-primary">Social</span>
            </div>
            <p className="mt-3 eyebrow text-ink-foreground/50">
              Content • Strategy • Copywriting
            </p>
          </div>
          <div className="flex gap-3">
            {socials.map((s) => (
              <a
                key={s.label}
                href={s.href}
                aria-label={s.label}
                target="_blank"
                rel="noreferrer"
                className="flex h-11 w-11 items-center justify-center rounded-full border border-ink-foreground/15 text-ink-foreground/70 transition-all duration-300 hover:border-primary hover:bg-primary hover:text-primary-foreground"
              >
                <s.icon className="h-4.5 w-4.5" strokeWidth={1.6} />
              </a>
            ))}
          </div>
        </div>

        <div className="flex flex-col items-center justify-between gap-4 pt-8 text-xs text-ink-foreground/40 sm:flex-row">
          <p>© {new Date().getFullYear()} Zaka Social. All rights reserved.</p>
          <p>Content, strategy &amp; copywriting that drive growth.</p>
        </div>
      </div>
    </footer>
  );
}
