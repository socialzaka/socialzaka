import { Reveal } from "./Reveal";

const steps = [
  {
    no: "01",
    title: "Discover",
    desc: "We learn about your business, audience, goals, and current challenges.",
  },
  {
    no: "02",
    title: "Strategize",
    desc: "We develop a content and messaging approach tailored to your brand.",
  },
  {
    no: "03",
    title: "Create",
    desc: "We build content plans, copy, and recommendations designed to support growth.",
  },
  {
    no: "04",
    title: "Refine",
    desc: "We analyze, improve, and adapt based on performance and business goals.",
  },
];

export function Process() {
  return (
    <section id="process" className="bg-background py-28 md:py-40">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <Reveal className="max-w-2xl">
          <div className="flex items-center gap-3 text-muted-foreground">
            <span className="h-px w-10 bg-primary" />
            <span className="eyebrow text-primary">Process</span>
          </div>
          <h2 className="mt-6 font-display text-[clamp(2rem,4.5vw,3.4rem)] font-medium leading-[1.02] tracking-[-0.02em]">
            How we <span className="italic text-primary">work.</span>
          </h2>
        </Reveal>

        <div className="mt-16 grid gap-10 md:grid-cols-2 lg:grid-cols-4 lg:gap-6">
          {steps.map((s, i) => (
            <Reveal key={s.no} delay={i * 100} className="relative">
              <div className="mb-6 flex items-center gap-4">
                <span className="font-display text-5xl font-medium text-primary md:text-6xl">
                  {s.no}
                </span>
                <span className="h-px flex-1 bg-border" />
              </div>
              <h3 className="font-display text-2xl font-semibold tracking-tight">
                {s.title}
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                {s.desc}
              </p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
