import { useEffect, useState } from "react";
import { Reveal } from "./Reveal";
import { Quote } from "lucide-react";

const testimonials = [
  {
    quote:
      "Zaka Social rebuilt our entire content approach. Within months our brand felt sharper, more consistent, and far more confident online.",
    label: "Real Estate Brand",
  },
  {
    quote:
      "The strategy came first, and it showed. Every post finally had a reason to exist — and the engagement followed naturally.",
    label: "Wellness Studio",
  },
  {
    quote:
      "Their copywriting made us sound like the premium brand we always knew we were. Clients now understand our value instantly.",
    label: "Eye Cosmetics Brand",
  },
  {
    quote:
      "Working with Zaka felt like having a creative partner, not a vendor. Thoughtful, intentional, and genuinely invested in our growth.",
    label: "Restaurant Owner",
  },
];

export function Testimonials() {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const id = setInterval(
      () => setActive((p) => (p + 1) % testimonials.length),
      6000,
    );
    return () => clearInterval(id);
  }, []);

  return (
    <section className="overflow-hidden bg-cream py-28 md:py-40">
      <div className="mx-auto max-w-5xl px-6 lg:px-10">
        <Reveal className="flex items-center justify-center gap-3 text-muted-foreground">
          <span className="h-px w-10 bg-primary" />
          <span className="eyebrow text-primary">Testimonials</span>
          <span className="h-px w-10 bg-primary" />
        </Reveal>

        <div className="relative mt-12">
          <Quote
            className="mx-auto mb-8 h-12 w-12 text-primary/30"
            strokeWidth={1.2}
          />
          <div className="relative min-h-[16rem] sm:min-h-[13rem]">
            {testimonials.map((t, i) => (
              <blockquote
                key={t.label}
                className={`absolute inset-0 flex flex-col items-center text-center transition-all duration-700 ${
                  i === active
                    ? "translate-y-0 opacity-100"
                    : "pointer-events-none translate-y-4 opacity-0"
                }`}
              >
                <p className="font-display text-2xl font-normal leading-snug tracking-tight text-balance md:text-[2rem]">
                  &ldquo;{t.quote}&rdquo;
                </p>
                <div className="mt-9 text-sm font-semibold tracking-wide text-muted-foreground uppercase">
                  {t.label}
                </div>
              </blockquote>
            ))}
          </div>

          <div className="mt-10 flex justify-center gap-2.5">
            {testimonials.map((t, i) => (
              <button
                key={t.label}
                aria-label={`Show testimonial ${i + 1}`}
                onClick={() => setActive(i)}
                className={`h-1.5 rounded-full transition-all duration-500 ${
                  i === active ? "w-8 bg-primary" : "w-1.5 bg-border hover:bg-muted-foreground"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
