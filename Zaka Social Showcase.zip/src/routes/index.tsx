import { createFileRoute } from "@tanstack/react-router";
import { Toaster } from "sonner";

import { Navbar } from "@/components/site/Navbar";
import { Hero } from "@/components/site/Hero";
import { About } from "@/components/site/About";
import { Services } from "@/components/site/Services";
import { Process } from "@/components/site/Process";
import { Industries } from "@/components/site/Industries";
import { Testimonials } from "@/components/site/Testimonials";
import { FinalCTA } from "@/components/site/FinalCTA";
import { Contact } from "@/components/site/Contact";
import { Footer } from "@/components/site/Footer";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Zaka Social — Content, Strategy & Copywriting That Drive Growth" },
      {
        name: "description",
        content:
          "Premium social media strategy, content planning, and copywriting that help brands attract attention, build trust, and grow online.",
      },
      {
        property: "og:title",
        content: "Zaka Social — Content, Strategy & Copywriting",
      },
      {
        property: "og:description",
        content:
          "We create content, messaging, and social media strategies that help businesses become impossible to ignore online.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Services />
        <Process />
        <Industries />
        <Testimonials />
        <FinalCTA />
        <Contact />
      </main>
      <Footer />
      <Toaster position="bottom-right" richColors />
    </div>
  );
}
