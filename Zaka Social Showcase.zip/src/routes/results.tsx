import { createFileRoute, Link } from "@tanstack/react-router";
import { Reveal } from "@/components/site/Reveal";
import {
  Users,
  Briefcase,
  CalendarCheck,
  Eye,
  Heart,
  TrendingUp,
  BarChart3,
  ArrowLeft,
} from "lucide-react";

const metrics = [
  {
    icon: Briefcase,
    value: "80+",
    label: "Brands Across the U.S., Brazil, Canada & Beyond",
  },
  {
    icon: Users,
    value: "30+",
    label: "Niches mastered with customized content approaches",
  },
  {
    icon: CalendarCheck,
    value: "600+",
    label: "Strategic content calendars created and delivered",
  },
];

const highlights = [
  {
    icon: Eye,
    value: "10.5M+",
    label: "Views in a single month",
    detail: "One client's results after strategic content publishing.",
  },
  {
    icon: Heart,
    value: "477.7K+",
    label: "Interactions",
    detail: "Likes, comments, shares, and saves driving engagement.",
  },
  {
    icon: TrendingUp,
    value: "2.8K+",
    label: "New followers",
    detail: "Followers gained from a single 15-second strategic video.",
  },
  {
    icon: BarChart3,
    value: "5,510",
    label: "Profile activities",
    detail: "Website clicks, emails, and direct messages generated.",
  },
];

const reelHighlights = [
  { value: "136,864", label: "Views on a top-performing reel" },
  { value: "13,162", label: "Views on a trending local reel" },
  { value: "6.5M+", label: "Views on a viral content series" },
  { value: "281K+", label: "Interactions on a single campaign" },
];

const brands = [
  "Eyederm Cosmetics",
  "Global Network Systems",
  "Newmark Commercial Real Estate",
  "PICCADILLY",
  "Duchess at the Nobleman",
  "Rausch PT & Wellness",
  "Assist Card",
  "Souldeo",
  "Synaptic Cycles",
  "A&E Tile and Marble, LLC",
  "Balanced Dental",
  "Quero Tudo Utilidades",
  "Carrano",
  "Global Vision",
  "Prim & Pure",
  "The Color Cove",
  "Perform Practice Solutions",
  "Matza Orthodontics",
  "Fabrispuma",
  "Uncommon Physical Therapy",
  "Go Tour Luxe",
  "Rosewood Remodeling Company",
  "Fairwinds Nantucket",
  "Mundo com Ju",
  "Kids Can Doodle",
  "Just Us Chix",
  "Bellhopping",
  "OnSite Medical Waste",
  "Kelly McDougall Real Estate in Bay Area",
];

export const Route = createFileRoute("/results")({
  head: () => ({
    meta: [
      { title: "Results — Zaka Social" },
      {
        name: "description",
        content:
          "Real results from 80+ brands across Brazil, the U.S., Europe, and Canada. See the metrics, growth, and impact Zaka Social delivers.",
      },
      { property: "og:title", content: "Results — Zaka Social" },
      {
        property: "og:description",
        content:
          "Real results from 80+ brands across Brazil, the U.S., Europe, and Canada.",
      },
    ],
  }),
  component: ResultsPage,
});

function ResultsPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Simple nav */}
      <header className="fixed inset-x-0 top-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border/60">
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-10">
          <Link
            to="/"
            className="group flex items-center gap-2"
          >
            <span className="font-display text-xl font-semibold tracking-tight">
              Zaka
            </span>
            <span className="font-display text-xl font-normal italic text-primary">
              Social
            </span>
          </Link>
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-sm font-medium text-foreground/70 transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" strokeWidth={1.6} />
            Back to home
          </Link>
        </nav>
      </header>

      <main className="pt-24">
        {/* Hero */}
        <section className="bg-ink py-24 md:py-32">
          <div className="mx-auto max-w-7xl px-6 lg:px-10">
            <Reveal>
              <div className="flex items-center gap-3 text-ink-foreground/60">
                <span className="h-px w-10 bg-primary" />
                <span className="eyebrow text-primary">Portfolio</span>
              </div>
              <h1 className="mt-6 max-w-3xl font-display text-[clamp(2.4rem,5.5vw,4rem)] font-medium leading-[1.02] tracking-[-0.02em] text-balance text-ink-foreground">
                Results that speak louder than{" "}
                <span className="italic text-primary">promises.</span>
              </h1>
              <p className="mt-6 max-w-xl text-lg leading-relaxed text-ink-foreground/70 md:text-xl">
                Helping brands grow through strategic content, social media, SEO, paid media, and website creation for over 5 years.
              </p>
            </Reveal>
          </div>
        </section>

        {/* Metrics */}
        <section className="bg-background py-28 md:py-40">
          <div className="mx-auto max-w-7xl px-6 lg:px-10">
            <Reveal className="max-w-2xl">
              <div className="flex items-center gap-3 text-muted-foreground">
                <span className="h-px w-10 bg-primary" />
                <span className="eyebrow text-primary">My Metrics</span>
              </div>
              <h2 className="mt-6 font-display text-[clamp(2rem,4.5vw,3.4rem)] font-medium leading-[1.02] tracking-[-0.02em] text-balance">
                Experience across{" "}
                <span className="italic text-primary">industries and continents.</span>
              </h2>
            </Reveal>

            <div className="mt-16 grid gap-6 sm:grid-cols-3">
              {metrics.map((m, i) => (
                <Reveal
                  key={m.label}
                  delay={i * 90}
                  className="rounded-3xl border border-border bg-card p-8 md:p-10"
                >
                  <div className="flex h-12 w-12 items-center justify-center rounded-full border border-border text-primary">
                    <m.icon className="h-5 w-5" strokeWidth={1.6} />
                  </div>
                  <div className="mt-7 font-display text-4xl font-semibold tracking-tight text-foreground md:text-5xl">
                    {m.value}
                  </div>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                    {m.label}
                  </p>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        {/* Results / Impact */}
        <section className="bg-cream py-28 md:py-40">
          <div className="mx-auto max-w-7xl px-6 lg:px-10">
            <Reveal className="max-w-2xl">
              <div className="flex items-center gap-3 text-muted-foreground">
                <span className="h-px w-10 bg-primary" />
                <span className="eyebrow text-primary">Results</span>
              </div>
              <h2 className="mt-6 font-display text-[clamp(2rem,4.5vw,3.4rem)] font-medium leading-[1.02] tracking-[-0.02em] text-balance">
                Real numbers from{" "}
                <span className="italic text-primary">real clients.</span>
              </h2>
            </Reveal>

            <div className="mt-16 grid gap-px overflow-hidden rounded-3xl border border-border bg-border sm:grid-cols-2">
              {highlights.map((h, i) => (
                <Reveal
                  key={h.label}
                  delay={(i % 2) * 90}
                  className="group relative bg-card p-9 transition-colors duration-500 hover:bg-ink md:p-10"
                >
                  <div className="flex h-12 w-12 items-center justify-center rounded-full border border-border text-primary transition-colors duration-500 group-hover:border-primary/40 group-hover:bg-primary/10">
                    <h.icon className="h-5 w-5" strokeWidth={1.6} />
                  </div>
                  <div className="mt-7 font-display text-3xl font-semibold tracking-tight text-foreground transition-colors duration-500 group-hover:text-ink-foreground md:text-4xl">
                    {h.value}
                  </div>
                  <h3 className="mt-2 font-display text-lg font-semibold tracking-tight transition-colors duration-500 group-hover:text-ink-foreground">
                    {h.label}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground transition-colors duration-500 group-hover:text-ink-foreground/70">
                    {h.detail}
                  </p>
                </Reveal>
              ))}
            </div>

            {/* Reel highlights */}
            <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {reelHighlights.map((r, i) => (
                <Reveal
                  key={r.label}
                  delay={i * 70}
                  className="rounded-2xl border border-border bg-background p-6 text-center"
                >
                  <div className="font-display text-2xl font-semibold tracking-tight text-foreground">
                    {r.value}
                  </div>
                  <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                    {r.label}
                  </p>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        {/* Brands */}
        <section className="bg-background py-28 md:py-40">
          <div className="mx-auto max-w-7xl px-6 lg:px-10">
            <Reveal className="max-w-2xl">
              <div className="flex items-center gap-3 text-muted-foreground">
                <span className="h-px w-10 bg-primary" />
                <span className="eyebrow text-primary">Brands</span>
              </div>
              <h2 className="mt-6 font-display text-[clamp(2rem,4.5vw,3.4rem)] font-medium leading-[1.02] tracking-[-0.02em] text-balance">
                Brands our team has worked with{" "}
                <span className="italic text-primary">throughout the years.</span>
              </h2>
            </Reveal>

            <div className="mt-16 flex flex-wrap gap-3">
              {brands.map((brand, i) => (
                <Reveal key={brand} delay={(i % 7) * 60}>
                  <span className="inline-block rounded-full border border-border bg-card px-5 py-2.5 text-sm font-medium text-foreground transition-colors hover:border-primary hover:text-primary">
                    {brand}
                  </span>
                </Reveal>
              ))}
            </div>

            <Reveal delay={200}>
              <p className="mt-10 text-sm text-muted-foreground">
                And many more across fashion, restaurants, dentistry, physical
                therapy, real estate, cosmetics, tech, remodeling, and beyond.
              </p>
            </Reveal>
          </div>
        </section>

        {/* CTA */}
        <section className="bg-ink py-24 md:py-32">
          <div className="mx-auto max-w-7xl px-6 text-center lg:px-10">
            <Reveal>
              <h2 className="font-display text-[clamp(2rem,4.5vw,3.4rem)] font-medium leading-[1.02] tracking-[-0.02em] text-balance text-ink-foreground">
                Ready to see your{" "}
                <span className="italic text-primary">own results?</span>
              </h2>
              <p className="mx-auto mt-6 max-w-xl text-lg leading-relaxed text-ink-foreground/70">
                Let's build a strategy that turns your brand's presence into real,
                measurable growth.
              </p>
              <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
                <a
                  href="mailto:socialzaka@gmail.com"
                  className="inline-flex items-center justify-center rounded-full bg-primary px-8 py-4 text-sm font-semibold text-primary-foreground transition-all duration-300 hover:scale-[1.03] hover:shadow-2xl hover:shadow-primary/20"
                >
                  Get in Touch
                </a>
                <Link
                  to="/"
                  className="inline-flex items-center justify-center rounded-full border border-ink-foreground/25 px-8 py-4 text-sm font-semibold text-ink-foreground transition-all duration-300 hover:border-ink-foreground/60 hover:bg-ink-foreground/5"
                >
                  Back to Home
                </Link>
              </div>
            </Reveal>
          </div>
        </section>
      </main>
    </div>
  );
}
